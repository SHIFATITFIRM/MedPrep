
import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Send, X, Bot, Loader2, BrainCircuit, BarChart3, ListChecks, RefreshCw, MessageSquare, Globe, ExternalLink, Calendar, Zap } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { StudyData, Subject, ChapterProgress } from '../types';
import { SUBJECTS, TASKS } from '../constants';

interface Message {
  role: 'user' | 'model';
  text: string;
  links?: { title: string; uri: string }[];
}

interface AIAssistantProps {
  data: StudyData;
  isOpen: boolean;
  onClose: () => void;
}

const AIAssistant: React.FC<AIAssistantProps> = ({ data, isOpen, onClose }) => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'strategy' | 'analysis' | 'chat' | 'search'>('strategy');
  
  // Chat states
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const getGeminiResponse = async (prompt: string, mode: 'flash' | 'pro' | 'search' = 'flash') => {
    setLoading(true);
    if (activeTab !== 'chat' && activeTab !== 'search') setResult(null);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      let model = 'gemini-3-flash-preview';
      let config: any = {
        systemInstruction: "You are 'MedPrep Guru', a highly intelligent medical admission coach for Bangladeshi HSC Science students. Your goal is to provide concise, encouraging, and high-yield study advice in a mix of Bengali and English (Banglish). Focus on medical admission patterns in Bangladesh (MAT). When providing a plan, use clear headings and bullet points.",
        temperature: 0.7,
      };

      if (mode === 'pro') {
        model = 'gemini-3-pro-preview';
      } else if (mode === 'search') {
        model = 'gemini-3-flash-preview';
        config.tools = [{ googleSearch: {} }];
      }

      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config,
      });

      const text = response.text || "Sorry, I couldn't generate a response.";
      
      let links: { title: string; uri: string }[] = [];
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (mode === 'search' && Array.isArray(chunks)) {
        links = chunks
          .map((chunk: any) => chunk.web)
          .filter((web: any) => web && web.uri && web.title);
      }

      if (activeTab === 'chat' || activeTab === 'search') {
        setMessages(prev => [...prev, { role: 'model', text, links: links.length > 0 ? links : undefined }]);
      } else {
        setResult(text);
      }
    } catch (error) {
      console.error("Gemini Error:", error);
      const errorMsg = "Oops! Something went wrong. Please check your internet connection and try again.";
      if (activeTab === 'chat' || activeTab === 'search') {
        setMessages(prev => [...prev, { role: 'model', text: errorMsg }]);
      } else {
        setResult(errorMsg);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userQuery = input.trim();
    setMessages(prev => [...prev, { role: 'user', text: userQuery }]);
    setInput('');
    
    const mode = activeTab === 'search' ? 'search' : 'pro';
    await getGeminiResponse(userQuery, mode);
  };

  const generateDailyStrategy = () => {
    const todayStr = new Date().toISOString().split('T')[0];
    const scheduled = (SUBJECTS || []).flatMap(sub => 
      (sub.chapters || [])
        .filter(ch => data.progress?.[sub.id]?.[ch.id]?.meta?.scheduledDate === todayStr)
        .map(ch => `${ch.name} (${sub.name})`)
    );

    // Context calculation
    const daysLeft = data.goals?.targetDate 
      ? Math.ceil((new Date(data.goals.targetDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
      : 'Not set';

    const totalPossibleTasks = (SUBJECTS || []).reduce((acc, sub) => acc + ((sub.chapters || []).length * (TASKS || []).length), 0);
    let completedTasks = 0;
    (SUBJECTS || []).forEach(sub => {
      const subProg = data.progress?.[sub.id] || {};
      Object.values(subProg).forEach(ch => {
        const chapterProg = ch as ChapterProgress;
        if (chapterProg && chapterProg.tasks) {
          completedTasks += Object.values(chapterProg.tasks).filter(Boolean).length;
        }
      });
    });
    const progressPercent = totalPossibleTasks > 0 ? Math.round((completedTasks / totalPossibleTasks) * 100) : 0;

    const prompt = `
      Create a high-performance personalized daily study plan for today.
      
      User Context:
      - Remaining Days to Exam: ${daysLeft}
      - Overall Preparation Progress: ${progressPercent}%
      - Current Streak: ${data.streak?.count || 0} days
      - Chapters Scheduled for Today: ${scheduled.length > 0 ? scheduled.join(', ') : 'None scheduled yet'}
      
      Please structure the response as:
      1. Morning Session (Memory & Core Concepts)
      2. Afternoon Session (Practice & Physics/Chemistry math)
      3. Evening Session (Question Bank & Active Recall)
      4. Guru's Secret Tip (1 high-yield medical admission fact)
      
      If no chapters are scheduled, recommend 2 high-yield topics based on the ${progressPercent}% progress level.
    `;
    
    getGeminiResponse(prompt, 'pro');
  };

  const generateAudit = () => {
    const summary = (SUBJECTS || []).map(sub => {
      const subProg = data.progress?.[sub.id] || {};
      const completed = Object.values(subProg).reduce((acc: number, ch) => {
        const chapterProg = ch as ChapterProgress;
        return acc + (chapterProg?.tasks ? Object.values(chapterProg.tasks).filter(Boolean).length : 0);
      }, 0);
      return `${sub.name}: ${completed} tasks completed.`;
    }).join('\n');

    const prompt = `Analyze my current preparation progress for the Medical Admission Test:\n${summary}\nStreak: ${data.streak?.count || 0} days.\nTarget Exam Date: ${data.goals?.targetDate || 'Not set'}.\n\nProvide a SWOT analysis (Strengths, Weaknesses, Opportunities, Threats) and a 'Guru Readiness Score' out of 100. Be brutally honest but encouraging.`;
    
    getGeminiResponse(prompt, 'pro');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
      <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] w-full max-w-2xl shadow-2xl overflow-hidden animate-pop flex flex-col h-[85vh]">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-gradient-to-r from-emerald-500/10 to-blue-500/10 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-600 rounded-2xl text-white shadow-lg">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-800 dark:text-slate-100">MedPrep <span className="text-emerald-600">AI Guru</span></h3>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Advanced Intelligence Hub</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors text-slate-400">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Action Tabs */}
        <div className="flex p-2 gap-1 bg-slate-50 dark:bg-slate-800/50 mx-6 mt-6 rounded-2xl border border-slate-100 dark:border-slate-700 shrink-0">
          {[
            { id: 'strategy', icon: Calendar, label: 'ডেইলি প্ল্যান' },
            { id: 'analysis', icon: BarChart3, label: 'প্রগ্রেস অডিট' },
            { id: 'chat', icon: MessageSquare, label: 'চ্যাট' },
            { id: 'search', icon: Globe, label: 'সার্চ' }
          ].map((tab) => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-bold transition-all ${activeTab === tab.id ? 'bg-white dark:bg-slate-700 text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <tab.icon className="w-4 h-4" /> {tab.label}
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6 flex flex-col">
          {(activeTab === 'chat' || activeTab === 'search') ? (
            <div className="flex-1 space-y-4">
              {messages.length === 0 && (
                <div className="text-center py-10 opacity-50 flex flex-col items-center">
                  <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-full mb-4">
                    {activeTab === 'chat' ? <MessageSquare className="w-8 h-8" /> : <Globe className="w-8 h-8" />}
                  </div>
                  <p className="text-sm font-medium">
                    {activeTab === 'chat' ? "Ask me anything about your studies or MAT!" : "Search for the latest medical admission updates."}
                  </p>
                </div>
              )}
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-slideUp`}>
                  <div className={`max-w-[85%] p-4 rounded-2xl text-sm ${
                    msg.role === 'user' 
                      ? 'bg-emerald-600 text-white rounded-tr-none' 
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-tl-none'
                  }`}>
                    <p className="whitespace-pre-wrap">{msg.text}</p>
                    {msg.links && msg.links.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700">
                        <p className="text-[10px] font-bold uppercase tracking-wider mb-2 opacity-60">Sources:</p>
                        <div className="flex flex-wrap gap-2">
                          {msg.links.map((link, idx) => (
                            <a 
                              key={idx} 
                              href={link.uri} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1.5 px-2 py-1 bg-white dark:bg-slate-700 rounded-md text-[10px] font-semibold text-emerald-600 hover:text-emerald-500 transition-colors"
                            >
                              <ExternalLink className="w-3 h-3" /> {link.title}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start animate-pulse">
                  <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-2xl rounded-tl-none">
                    <Loader2 className="w-5 h-5 animate-spin text-emerald-600" />
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>
          ) : (
            <div className="flex-1">
              {!result && !loading ? (
                <div className="text-center py-12 flex flex-col items-center">
                  <div className="w-20 h-20 bg-emerald-50 dark:bg-emerald-900/20 rounded-full flex items-center justify-center mb-4 animate-pulse">
                    <Sparkles className="w-10 h-10 text-emerald-500" />
                  </div>
                  <h4 className="text-lg font-bold text-slate-700 dark:text-slate-200 mb-2">
                    {activeTab === 'strategy' ? 'আজকের সেরা স্টাডি প্ল্যান দরকার?' : 'প্রস্তুতির গভীর বিশ্লেষণ চান?'}
                  </h4>
                  <p className="text-xs text-slate-400 mb-6 max-w-[280px] mx-auto">AI আপনার প্রগ্রেস ডাটা এনালাইজ করে পার্সোনালাইজড রেজাল্ট তৈরি করবে।</p>
                  <button 
                    onClick={activeTab === 'strategy' ? generateDailyStrategy : generateAudit}
                    className="flex items-center gap-2 bg-slate-900 dark:bg-emerald-600 text-white px-8 py-3.5 rounded-2xl font-black text-sm hover:scale-105 transition-all shadow-xl active:scale-95"
                  >
                    <Zap className="w-4 h-4 text-amber-400 fill-amber-400" /> ম্যাজিক দেখুন
                  </button>
                </div>
              ) : loading ? (
                <div className="flex flex-col items-center justify-center py-20 gap-4">
                  <div className="relative">
                     <Loader2 className="w-12 h-12 text-emerald-500 animate-spin" />
                     <Bot className="w-6 h-6 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-emerald-500" />
                  </div>
                  <p className="text-sm font-bold text-slate-400 animate-pulse uppercase tracking-widest">AI Guru ডাটা এনালাইজ করছে...</p>
                </div>
              ) : (
                <div className="animate-slideUp max-w-none">
                  <div className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-[2rem] border border-slate-100 dark:border-slate-700 whitespace-pre-wrap text-slate-700 dark:text-slate-300 leading-relaxed text-sm shadow-inner">
                    <div className="flex items-center gap-2 mb-4 pb-4 border-b border-slate-200 dark:border-slate-700">
                      <Bot className="w-5 h-5 text-emerald-600" />
                      <span className="font-black text-xs uppercase tracking-tighter text-slate-400">Personalized Insights</span>
                    </div>
                    {result}
                  </div>
                  <button onClick={() => setResult(null)} className="mt-6 mx-auto flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-slate-600 transition-colors">
                    <RefreshCw className="w-3 h-3" /> তথ্য রিফ্রেশ করুন
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Input area for Chat/Search */}
        {(activeTab === 'chat' || activeTab === 'search') && (
          <div className="p-6 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 shrink-0">
            <form onSubmit={handleSendMessage} className="flex gap-2">
              <input 
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={activeTab === 'search' ? "Search for MAT dates, circulars, etc..." : "Ask your Guru anything..."}
                className="flex-1 bg-slate-100 dark:bg-slate-800 border-none rounded-2xl px-5 py-3.5 text-sm text-slate-800 dark:text-slate-100 outline-none ring-2 ring-transparent focus:ring-emerald-500 transition-all"
                disabled={loading}
              />
              <button 
                type="submit"
                disabled={loading || !input.trim()}
                className="bg-emerald-600 text-white p-3.5 rounded-2xl hover:bg-emerald-500 disabled:opacity-50 transition-all active:scale-95 shadow-lg shadow-emerald-200 dark:shadow-none"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </div>
        )}
        
        <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-700 text-center shrink-0">
           <p className="text-[10px] text-slate-400 font-medium tracking-tight">Advanced Reasoning powered by Gemini 3 Pro Intelligence.</p>
        </div>
      </div>
    </div>
  );
};

export default AIAssistant;
