
import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { SubjectStats } from '../types';

interface StatsDashboardProps {
  stats: SubjectStats[];
  overallProgress: number;
}

const StatsDashboard: React.FC<StatsDashboardProps> = ({ stats, overallProgress }) => {
  const isDark = document.documentElement.classList.contains('dark');
  
  const pieData = [
    { name: 'Completed', value: overallProgress, color: '#10b981' },
    { name: 'Remaining', value: 100 - overallProgress, color: isDark ? '#1e293b' : '#e2e8f0' },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
      {/* Overall Summary */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center relative overflow-hidden transition-colors">
        <div className="absolute top-0 right-0 p-4 opacity-5">
          <div className="w-32 h-32 rounded-full bg-emerald-500 blur-3xl"></div>
        </div>
        
        <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-6 w-full text-center">সার্বিক অগ্রগতি</h3>
        
        <div className="relative w-48 h-48">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={0}
                dataKey="value"
                startAngle={90}
                endAngle={-270}
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <span className="text-4xl font-extrabold text-slate-800 dark:text-slate-100">{Math.round(overallProgress)}%</span>
            <span className="text-xs font-semibold text-emerald-600 tracking-wider">মোট সম্পন্ন</span>
          </div>
        </div>
      </div>

      {/* Subject-wise Bar Chart */}
      <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 transition-colors">
        <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-6">বিষয়ভিত্তিক তুলনা</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={stats}
              margin={{ top: 5, right: 30, left: 0, bottom: 5 }}
              layout="vertical"
            >
              <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke={isDark ? '#1e293b' : '#f1f5f9'} />
              <XAxis type="number" domain={[0, 100]} hide />
              <YAxis 
                dataKey="name" 
                type="category" 
                width={120} 
                axisLine={false} 
                tickLine={false}
                tick={{ fontSize: 10, fontWeight: 600, fill: isDark ? '#94a3b8' : '#64748b' }}
              />
              <Tooltip 
                cursor={{ fill: 'transparent' }}
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-white dark:bg-slate-800 p-2 shadow-lg border border-slate-100 dark:border-slate-700 rounded-lg">
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-100">{`${payload[0].value}% Complete`}</p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar 
                dataKey="percentage" 
                radius={[0, 10, 10, 0]} 
                barSize={16}
              >
                {stats.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default StatsDashboard;
