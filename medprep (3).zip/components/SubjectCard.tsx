
import React, { useState } from 'react';
import { ChevronRight, ChevronDown, BookOpen } from 'lucide-react';
import { Subject, SubjectProgress, Task, ChapterProgress } from '../types';
import ChapterRow from './ChapterRow';
import ProgressBar from './ProgressBar';

interface SubjectCardProps {
  subject: Subject;
  tasks: Task[];
  progress: SubjectProgress;
  onToggleTask: (chapterId: string, taskId: string) => void;
  onUpdateMeta: (chapterId: string, meta: Partial<ChapterProgress['meta']>) => void;
}

const SubjectCard: React.FC<SubjectCardProps> = ({ 
  subject, 
  tasks, 
  progress, 
  onToggleTask,
  onUpdateMeta
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const totalTasks = subject.chapters.length * tasks.length;
  let completedTasks = 0;
  subject.chapters.forEach(ch => {
    const chProg = progress[ch.id];
    if (chProg) {
      completedTasks += Object.values(chProg.tasks || {}).filter(Boolean).length;
    }
  });
  
  const percentage = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden transition-all duration-300">
      <div 
        className={`p-5 cursor-pointer flex flex-col gap-4 ${isExpanded ? 'bg-slate-50/50 dark:bg-slate-800/30' : ''}`}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div 
              className="p-2.5 rounded-xl text-white shadow-sm"
              style={{ backgroundColor: subject.color }}
            >
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 dark:text-slate-100 text-lg leading-tight">{subject.name}</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">{subject.chapters.length} Chapters</p>
            </div>
          </div>
          <div className="p-2 rounded-full hover:bg-white dark:hover:bg-slate-800 transition-colors">
            {isExpanded ? <ChevronDown className="w-5 h-5 text-slate-400" /> : <ChevronRight className="w-5 h-5 text-slate-400" />}
          </div>
        </div>

        <ProgressBar progress={percentage} color={subject.color} />
      </div>

      {isExpanded && (
        <div className="border-t border-slate-100 dark:border-slate-800">
          {subject.chapters.map((chapter) => (
            <ChapterRow
              key={chapter.id}
              chapter={chapter}
              tasks={tasks}
              // Added scheduledDate: null to the default ChapterProgress object to fix type mismatch error where scheduledDate was required by ChapterMeta
              progress={progress[chapter.id] || { tasks: {}, meta: { priority: 'medium', difficulty: 'medium', timeSpent: 0, scheduledDate: null } }}
              onToggleTask={(taskId) => onToggleTask(chapter.id, taskId)}
              onUpdateMeta={(meta) => onUpdateMeta(chapter.id, meta)}
              accentColor={subject.color}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default SubjectCard;
