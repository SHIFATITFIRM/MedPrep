
import React from 'react';

interface ProgressBarProps {
  progress: number;
  color?: string;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ 
  progress, 
  color = '#3b82f6', 
  size = 'md',
  showLabel = true 
}) => {
  const height = size === 'sm' ? 'h-1.5' : size === 'md' ? 'h-3' : 'h-5';
  
  return (
    <div className="w-full">
      <div className={`flex justify-between items-center ${showLabel ? 'mb-1' : ''}`}>
        {showLabel && (
          <span className="text-xs font-medium text-slate-500">{Math.round(progress)}% Complete</span>
        )}
      </div>
      <div className={`w-full bg-slate-200 rounded-full overflow-hidden ${height}`}>
        <div
          className="h-full transition-all duration-500 ease-out"
          style={{ width: `${progress}%`, backgroundColor: color }}
        />
      </div>
    </div>
  );
};

export default ProgressBar;
