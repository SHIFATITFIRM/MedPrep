
import React from 'react';
import { CalendarCheck, BookOpen, CheckCircle2 } from 'lucide-react';
import { SUBJECTS, TASKS } from '../constants';
import { StudyData } from '../types';
import ProgressBar from './ProgressBar';

interface TodayTasksPanelProps {
  data: StudyData;
}

const TodayTasksPanel: React.FC<TodayTasksPanelProps> = ({ data }) => {
  const todayStr = new Date().toISOString().split('T')[0];
  
  const todayTasks = SUBJECTS.flatMap(sub => 
    (sub.chapters || [])
      .filter(ch => data.progress?.[sub.id]?.[ch.id]?.meta?.scheduledDate === todayStr)
      .map(ch => ({
        ...ch,
        subjectName: sub.name,
        subjectColor: sub.color,
        subjectId: sub.id,
        progress: data.progress?.[sub.id]?.[ch.id]
      }))
  );

  if (todayTasks.length === 0) return null;

  return (
    <div className="mb-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
      <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
        <div className="p-2 bg-emerald-100 dark:bg-emerald-900/30 rounded-lg text-emerald-600">
          <CalendarCheck className="w-5 h-5" />
        </div>
        <div>
          <h3 className="font-bold text-slate-800 dark:text-slate-100">আজকের টার্গেট</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">{todayTasks.length} টি অধ্যায় আজকের জন্য নির্ধারিত</p>
        </div>
      </div>
      <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-80 overflow-y-auto">
        {todayTasks.map(task => {
          const completedCount = Object.values(task.progress?.tasks || {}).filter(Boolean).length;
          const percentage = (completedCount / TASKS.length) * 100;

          return (
            <div key={`${task.subjectId}-${task.id}`} className="p-4 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-bold text-slate-700 dark:text-slate-200">{task.name}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 font-medium truncate max-w-[120px]">
                    {task.subjectName}
                  </span>
                </div>
                <ProgressBar progress={percentage} color={task.subjectColor} size="sm" showLabel={false} />
              </div>
              <div className="ml-4 flex items-center gap-2">
                <span className="text-xs font-bold text-slate-400">{completedCount}/{TASKS.length}</span>
                {percentage === 100 && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default TodayTasksPanel;
