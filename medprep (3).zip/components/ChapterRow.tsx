
import React, { useState, useEffect, useRef } from 'react';
import { ChevronDown, ChevronUp, CheckCircle2, Circle, Play, Pause, Timer, Tag, AlertTriangle, CalendarDays, Sparkles, Loader2 } from 'lucide-react';
import { Chapter, Task, ChapterProgress, Priority, Difficulty } from '../types';
import ProgressBar from './ProgressBar';
import confetti from 'canvas-confetti';
import { GoogleGenAI } from "@google/genai";

interface ChapterRowProps {
  chapter: Chapter;
  tasks: Task[];
  progress: ChapterProgress;
  onToggleTask: (taskId: string) => void;
  onUpdateMeta: (meta: Partial<ChapterProgress['meta']>) => void;
  accentColor: string;
}

const ChapterRow: React.FC<ChapterRowProps> = ({ 
  chapter, 
  tasks, 
  progress, 
  onToggleTask,
  onUpdateMeta,
  accentColor 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiTip, setAiTip] = useState<string | null>(null);
  const timerRef = useRef<number | null>(null);

  const completedCount = Object.values(progress.tasks || {}).filter(Boolean).length;
  const percentage = (completedCount / tasks.length) * 100;
  const isFullyComplete = percentage === 100;

  const todayStr = new Date().toISOString().split('T')[0];
  const isScheduledForToday = progress.meta.scheduledDate === todayStr;

  // Timer Logic
  useEffect(() => {
    if (isTimerRunning) {
      timerRef.current = window.setInterval(() => {
        onUpdateMeta({ timeSpent: (progress.meta.timeSpent || 0) + 1 });
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isTimerRunning, progress.meta.timeSpent, onUpdateMeta]);

  const fetchAiTip = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (aiTip) {
      setAiTip(null);
      return;
    }
    
    setAiLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Provide 3 short, extremely high-yield bullet points for medical admission preparation (MAT) for the chapter: "${chapter.name}". Include what type of questions are common. Respond in Banglish (Bengali with English terms).`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          systemInstruction: "You are a Medical Admission Test expert.",
          temperature: 0.5,
        },
      });
      setAiTip(response.text || "No specific tips found.");
    } catch (err) {
      setAiTip("Could not load tips. Try again later.");
    } finally {
      setAiLoading(false);
    }
  };

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h > 0 ? h + 'h ' : ''}${m}m ${s}s`;
  };

  const handleToggle = (taskId: string) => {
    const wasChecking = !progress.tasks[taskId];
    onToggleTask(taskId);

    // If this specific check completes the chapter
    if (wasChecking && completedCount === tasks.length - 1) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: [accentColor, '#10b981', '#ffffff']
      });
    }
  };

  const toggleTodaySchedule = (e: React.MouseEvent) => {
    e.stopPropagation();
    onUpdateMeta({ scheduledDate: isScheduledForToday ? null : todayStr });
  };

  return (
    <div className="border-b border-slate-100 dark:border-slate-800 last:border-none">
      <div className="flex items-center p-4 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex-1 flex items-center gap-4 text-left"
        >
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className={`text-sm font-semibold transition-colors ${isFullyComplete ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-700 dark:text-slate-200'}`}>
                {chapter.name}
              </span>
              {progress.meta.priority === 'high' && <AlertTriangle className="w-3 h-3 text-red-500" />}
              {isFullyComplete && <CheckCircle2 className="w-4 h-4 text-emerald-500 animate-pop" />}
            </div>
            <ProgressBar progress={percentage} color={accentColor} size="sm" showLabel={false} />
          </div>
        </button>

        <div className="flex items-center gap-2 ml-4">
          {/* AI Tip Button */}
          <button 
            onClick={fetchAiTip}
            className={`p-2 rounded-lg transition-all active:scale-90 ${aiTip ? 'bg-amber-100 text-amber-600' : 'bg-slate-100 dark:bg-slate-700 text-slate-400 hover:text-amber-500'}`}
            title="AI Revision Tips"
          >
            {aiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          </button>

          <button 
            onClick={toggleTodaySchedule}
            className={`p-2 rounded-lg transition-all active:scale-90 hidden sm:block ${isScheduledForToday ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 dark:bg-slate-700 text-slate-400'}`}
            title={isScheduledForToday ? "আজকের তালিকা থেকে সরান" : "আজকের তালিকায় যোগ করুন"}
          >
            <CalendarDays className="w-4 h-4" />
          </button>
          
          <button 
            onClick={() => setIsTimerRunning(!isTimerRunning)}
            className={`p-2 rounded-lg transition-all active:scale-95 ${isTimerRunning ? 'bg-red-100 text-red-600 animate-pulse shadow-sm shadow-red-200' : 'bg-slate-100 dark:bg-slate-700 text-slate-500'}`}
          >
            {isTimerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>
          
          <button onClick={() => setIsOpen(!isOpen)} className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors">
            {isOpen ? <ChevronUp className="w-5 h-5 text-slate-400" /> : <ChevronDown className="w-5 h-5 text-slate-400" />}
          </button>
        </div>
      </div>

      {/* AI Tip Box */}
      {aiTip && (
        <div className="px-4 pb-4 animate-slideUp">
          <div className="bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-900/30 p-4 rounded-2xl">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span className="text-[10px] font-black uppercase tracking-widest text-amber-700 dark:text-amber-400">AI Medical Insights</span>
            </div>
            <p className="text-xs text-amber-800 dark:text-amber-200 leading-relaxed whitespace-pre-wrap">{aiTip}</p>
          </div>
        </div>
      )}

      {isOpen && (
        <div className="bg-slate-50 dark:bg-slate-900/50 p-4 pt-0 space-y-4 animate-slideUp">
          <div className="flex flex-wrap gap-2 mb-2">
            <div className="flex items-center gap-2 bg-white dark:bg-slate-800 p-1.5 rounded-xl border border-slate-200 dark:border-slate-700">
              <span className="text-[10px] font-bold text-slate-400 ml-1 uppercase tracking-wider">Priority</span>
              <select 
                value={progress.meta.priority}
                onChange={(e) => onUpdateMeta({ priority: e.target.value as Priority })}
                className="text-[10px] font-bold bg-transparent outline-none text-slate-700 dark:text-slate-300 pr-2 cursor-pointer"
              >
                <option value="low">LOW</option>
                <option value="medium">MEDIUM</option>
                <option value="high">HIGH</option>
              </select>
            </div>
            
            <div className="flex items-center gap-2 bg-white dark:bg-slate-800 p-1.5 rounded-xl border border-slate-200 dark:border-slate-700">
              <span className="text-[10px] font-bold text-slate-400 ml-1 uppercase tracking-wider">Difficulty</span>
              <select 
                value={progress.meta.difficulty}
                onChange={(e) => onUpdateMeta({ difficulty: e.target.value as Difficulty })}
                className="text-[10px] font-bold bg-transparent outline-none text-slate-700 dark:text-slate-300 pr-2 cursor-pointer"
              >
                <option value="easy">EASY</option>
                <option value="medium">MEDIUM</option>
                <option value="hard">HARD</option>
              </select>
            </div>

            <div className="flex items-center gap-2 bg-white dark:bg-slate-800 p-1.5 rounded-xl border border-slate-200 dark:border-slate-700">
              <Timer className="w-3 h-3 text-slate-400 ml-1" />
              <span className="text-[10px] font-bold text-slate-700 dark:text-slate-300 pr-2">{formatTime(progress.meta.timeSpent || 0)}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {tasks.map((task) => {
              const isChecked = progress.tasks[task.id] || false;
              return (
                <label
                  key={task.id}
                  className={`flex items-center gap-3 p-3 rounded-xl border transition-all cursor-pointer select-none active:scale-[0.98] ${
                    isChecked 
                      ? 'bg-white dark:bg-slate-800 border-emerald-200 dark:border-emerald-900 shadow-sm animate-pop' 
                      : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-slate-300'
                  }`}
                >
                  <input
                    type="checkbox"
                    className="hidden"
                    checked={isChecked}
                    onChange={() => handleToggle(task.id)}
                  />
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center transition-all ${isChecked ? 'bg-emerald-500 text-white' : 'border-2 border-slate-300 dark:border-slate-600'}`}>
                    {isChecked && (
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="4">
                        <path className="checkmark-path" strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </div>
                  <span className={`text-sm ${isChecked ? 'text-slate-800 dark:text-slate-100 font-medium' : 'text-slate-600 dark:text-slate-400'}`}>
                    {task.label}
                  </span>
                </label>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default ChapterRow;
