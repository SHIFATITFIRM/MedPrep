
import React, { useState } from 'react';
import { Bell, Plus, Trash2, Clock, CheckCircle } from 'lucide-react';
import { Reminder } from '../types';
import { SUBJECTS } from '../constants';

interface ReminderSettingsProps {
  reminders: Reminder[];
  onUpdate: (reminders: Reminder[]) => void;
  onClose: () => void;
}

const ReminderSettings: React.FC<ReminderSettingsProps> = ({ reminders, onUpdate, onClose }) => {
  const [newTime, setNewTime] = useState("18:00");
  const [newSub, setNewSub] = useState("");

  const addReminder = () => {
    const reminder: Reminder = {
      id: Math.random().toString(36).substr(2, 9),
      time: newTime,
      subjectId: newSub || undefined,
      enabled: true
    };
    onUpdate([...reminders, reminder]);
  };

  const removeReminder = (id: string) => {
    onUpdate(reminders.filter(r => r.id !== id));
  };

  const toggleReminder = (id: string) => {
    onUpdate(reminders.map(r => r.id === id ? { ...r, enabled: !r.enabled } : r));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
          <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Bell className="w-5 h-5 text-emerald-600" /> পড়াশোনার রিমাইন্ডার
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <Plus className="w-6 h-6 rotate-45" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Add New */}
          <div className="space-y-3">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">নতুন রিমাইন্ডার যোগ করুন</p>
            <div className="flex gap-2">
              <input 
                type="time" 
                value={newTime} 
                onChange={e => setNewTime(e.target.value)}
                className="flex-1 bg-slate-50 dark:bg-slate-800 border-none rounded-xl p-3 text-slate-800 dark:text-slate-100 outline-none ring-2 ring-transparent focus:ring-emerald-500 transition-all"
              />
              <select 
                value={newSub}
                onChange={e => setNewSub(e.target.value)}
                className="flex-[2] bg-slate-50 dark:bg-slate-800 border-none rounded-xl p-3 text-slate-800 dark:text-slate-100 outline-none ring-2 ring-transparent focus:ring-emerald-500 transition-all text-sm"
              >
                <option value="">সকল বিষয়</option>
                {SUBJECTS.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
              <button 
                onClick={addReminder}
                className="bg-emerald-600 hover:bg-emerald-700 text-white p-3 rounded-xl transition-colors shadow-lg shadow-emerald-200 dark:shadow-none"
              >
                <Plus className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* List */}
          <div className="space-y-3">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">আপনার রিমাইন্ডারসমূহ</p>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {reminders.length === 0 && (
                <div className="text-center py-8 text-slate-400 bg-slate-50 dark:bg-slate-800/50 rounded-2xl">
                  <Clock className="w-10 h-10 mx-auto mb-2 opacity-20" />
                  <p className="text-sm">কোন রিমাইন্ডার সেট করা নেই</p>
                </div>
              )}
              {reminders.map(r => (
                <div key={r.id} className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${r.enabled ? 'bg-white dark:bg-slate-800 border-emerald-100 dark:border-emerald-900/50' : 'bg-slate-50 dark:bg-slate-900/50 border-transparent opacity-60'}`}>
                  <div className="flex items-center gap-4">
                    <button onClick={() => toggleReminder(r.id)} className={`w-10 h-6 rounded-full relative transition-colors ${r.enabled ? 'bg-emerald-500' : 'bg-slate-300'}`}>
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${r.enabled ? 'left-5' : 'left-1'}`} />
                    </button>
                    <div>
                      <p className="text-lg font-bold text-slate-800 dark:text-slate-100 leading-none">{r.time}</p>
                      <p className="text-xs text-slate-500 mt-1">
                        {r.subjectId ? SUBJECTS.find(s => s.id === r.subjectId)?.name : 'সকল বিষয়'}
                      </p>
                    </div>
                  </div>
                  <button onClick={() => removeReminder(r.id)} className="text-slate-300 hover:text-red-500 transition-colors p-2">
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="p-6 bg-slate-50 dark:bg-slate-800/50 flex justify-center">
          <button 
            onClick={onClose}
            className="flex items-center gap-2 bg-slate-800 text-white px-8 py-3 rounded-xl font-bold hover:bg-slate-700 transition-all"
          >
            <CheckCircle className="w-5 h-5" /> হয়ে গেছে
          </button>
        </div>
      </div>
    </div>
  );
};

export default ReminderSettings;
